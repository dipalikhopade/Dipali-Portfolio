import React, { useState } from 'react';
import './ContactUs.css';
import { Button, Container, Modal } from 'react-bootstrap';

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [errors, setErrors] = useState({
    name: false,
    email: false,
    message: false
  });

  const [showSuccess, setShowSuccess] = useState(false); // State for success modal

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: false }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Form validation: Check if any field is empty
    const newErrors = {
      name: formData.name.trim() === '',
      email: formData.email.trim() === '',
      message: formData.message.trim() === ''
    };

    setErrors(newErrors);

    // Check if any error exists
    if (Object.values(newErrors).some(error => error)) {
      console.log("Please fill out all fields.");
      return;
    }

    // Show success message and reset the form
    setShowSuccess(true);
    setFormData({ name: '', email: '', message: '' });
  };

  const handleClose = () => setShowSuccess(false);

  return (
    <Container fluid className="about-section">
      <div>
        <h2 style={{ fontSize: "2.1em", paddingBottom: "20px" }}>Contact Us</h2>
        <form onSubmit={handleSubmit} className="project-card">
          <div>
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Enter your name"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <p style={{ color: 'red' }}>Name is required</p>}
          </div>

          <div>
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <p style={{ color: 'red' }}>Email is required</p>}
          </div>

          <div>
            <label htmlFor="message">Message:</label>
            <textarea
              id="message"
              name="message"
              placeholder="Enter your message"
              value={formData.message}
              onChange={handleChange}
            />
            {errors.message && <p style={{ color: 'red' }}>Message is required</p>}
          </div>

          <Button type="submit">Submit</Button>
        </form>
      </div>

      {/* Success Modal */}
      <Modal show={showSuccess} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Form Submitted</Modal.Title>
        </Modal.Header>
        <Modal.Body>Your message has been successfully submitted!</Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default ContactUs;
